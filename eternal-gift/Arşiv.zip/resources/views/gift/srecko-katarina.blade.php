<!DOCTYPE html>
<html lang="sr" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Srećko & Katarina & Laura - Eternal Gift</title>
    
    <!-- Tailwind CSS (CDN for standalone usage) -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        serif: ['"Playfair Display"', 'serif'],
                        sans: ['"Inter"', 'sans-serif'],
                    },
                    colors: {
                        'eternal-gold': '#d4af37',
                    },
                    animation: {
                        'fade-in': 'fadeIn 1.5s ease-out forwards',
                        'zoom-out': 'zoomOut 10s ease-out forwards',
                        'shake': 'shake 0.5s cubic-bezier(.36,.07,.19,.97) both',
                    },
                    keyframes: {
                        fadeIn: {
                            '0%': { opacity: '0', transform: 'translateY(20px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' },
                        },
                        zoomOut: {
                            '0%': { transform: 'scale(1.05)' },
                            '100%': { transform: 'scale(1.0)' },
                        },
                        shake: {
                            '10%, 90%': { transform: 'translate3d(-1px, 0, 0)' },
                            '20%, 80%': { transform: 'translate3d(2px, 0, 0)' },
                            '30%, 50%, 70%': { transform: 'translate3d(-4px, 0, 0)' },
                            '40%, 60%': { transform: 'translate3d(4px, 0, 0)' }
                        }
                    }
                }
            }
        }
    </script>
    
    <style>
        /* Custom Scrollbar for Dark Mode */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #111827; }
        ::-webkit-scrollbar-thumb { background: #374151; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #4b5563; }

        /* Overlay Transitions */
        #password-overlay {
            transition: opacity 1.5s ease-in-out, visibility 1.5s;
        }
        #password-overlay.hidden-overlay {
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
        }
    </style>
</head>
<body class="bg-gray-900 text-gray-200 font-sans antialiased overflow-x-hidden selection:bg-amber-500/30">

    <!-- PASSWORD OVERLAY -->
    <div id="password-overlay" class="fixed inset-0 z-[100] bg-gray-900 flex flex-col items-center justify-center text-center">
        <div class="mb-12 opacity-80 animate-pulse">
            <svg class="w-12 h-12 mx-auto text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
            </svg>
        </div>

        <div class="relative group">
            <input type="password" 
                   id="password-input"
                   placeholder="Who is the light?" 
                   class="bg-transparent border-b border-gray-700 text-center text-3xl tracking-[0.2em] text-gray-300 focus:outline-none focus:border-amber-500 w-80 pb-2 transition-colors duration-500 placeholder-gray-700 font-serif italic"
                   autocomplete="off">
            <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-[1px] bg-amber-500 transition-all duration-700 group-hover:w-full peer-focus:w-full"></div>
        </div>
        
        <p id="hint" class="mt-8 text-xs text-gray-600 tracking-widest uppercase opacity-0 transition-opacity duration-1000">Enter the name</p>
    </div>

    <!-- MAIN CONTENT -->
    <div id="main-content">
        <!-- Audio Player (Hidden) -->
        <audio id="bg-music" loop>
            <source src="{{ asset('audio/piano.mp3') }}" type="audio/mpeg">
        </audio>
        
        <!-- Floating Play Button -->
        <button onclick="document.getElementById('bg-music').play()" class="fixed bottom-6 right-6 z-50 bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-full hover:bg-white/20 transition-all duration-300 group shadow-2xl">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 text-white group-hover:scale-110 transition-transform">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 9l10.5-3m0 6.553v3.75a2.25 2.25 0 01-1.632 2.163l-1.32.377a1.803 1.803 0 11-.99-3.467l2.31-.66a2.25 2.25 0 001.632-2.163zm0 0V2.25L9 5.25v10.303m0 0v3.75a2.25 2.25 0 01-1.632 2.163l-1.32.377a1.803 1.803 0 11-.99-3.467l2.31-.66a2.25 2.25 0 001.632-2.163z" />
            </svg>
        </button>

        <!-- HERO SECTION (Cinematic Video) -->
        <section class="relative h-screen flex items-center justify-center overflow-hidden">
            <!-- Video Background -->
            <div class="absolute inset-0 z-0">
                <video id="hero-video" loop muted playsinline class="w-full h-full object-cover object-[50%_25%]">
                    <source src="{{ asset('videos/dance.mp4') }}" type="video/mp4">
                </video>
                <!-- Cinematic Gradient Overlay -->
                <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-gray-900"></div>
            </div>

            <!-- Hero Content -->
            <div class="relative z-10 text-center px-4 max-w-5xl mx-auto">
                <div class="space-y-6 animate-fade-in">
                    <p class="text-white/80 uppercase tracking-[0.3em] text-sm md:text-base font-medium">Belgrade, 2022</p>
                    
                    <h1 class="text-6xl md:text-8xl lg:text-9xl text-white font-serif italic mb-6 drop-shadow-lg">
                        Srećko & Katarina
                    </h1>
                    
                    <div class="w-24 h-px bg-white/50 mx-auto my-8"></div>
                    
                    <p class="text-xl md:text-3xl text-white/90 font-light italic font-serif">
                        "Naš prvi ples, naš večni krug."
                    </p>
                </div>
                
                <div class="mt-16 animate-pulse opacity-60">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8 text-white mx-auto">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                    </svg>
                </div>
            </div>
        </section>

        <!-- STORY SECTION -->
        <section class="bg-gray-900 py-24 px-6 md:px-12 border-t border-white/5 relative z-10">
            <div class="max-w-7xl mx-auto">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
                    <!-- Image -->
                    <div class="relative group">
                        <div class="absolute inset-0 bg-amber-300/10 blur-2xl rounded-full opacity-20 group-hover:opacity-40 transition-opacity duration-700"></div>
                        <img src="{{ asset('images/first.jpeg') }}" alt="Our Beginning" class="relative z-10 w-full h-[600px] object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 ease-in-out rounded-sm shadow-2xl">
                        <div class="absolute -bottom-6 -right-6 w-32 h-32 border border-white/20 z-0 hidden md:block"></div>
                    </div>
                    
                    <!-- Text -->
                    <div class="space-y-8">
                        <h2 class="text-4xl md:text-5xl text-white font-serif italic">
                            Početak Naše Priče
                        </h2>
                        <p class="text-lg text-gray-400 leading-relaxed font-light">
                            <strong class="text-amber-200">Her şey bir merhaba ile başladı...</strong> 
                            Taj prvi trenutak, onaj prvi pogled, postao je temelj svega divnog što danas imamo. Ne samo da smo pronašli ljubav, već smo pronašli dom jedno u drugom.
                        </p>
                        <p class="text-lg text-gray-400 leading-relaxed font-light">
                            Iz dana u dan, naša ljubav raste kao najlepša melodija. Zajedno smo izgradili svet ispunjen smehom, podrškom i beskrajnom srećom koja sada ima ime - Laura.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- LAURA'S GALLERY -->
        <section class="bg-gray-900 py-32 px-6 border-t border-white/5">
            <div class="max-w-7xl mx-auto">
                <div class="text-center mb-20 space-y-4">
                    <span class="text-amber-300/80 uppercase tracking-widest text-sm">Naše Blago</span>
                    <h2 class="text-5xl md:text-6xl text-white font-serif italic">Naše Sunce, Laura</h2>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <!-- Photo 1: Birth -->
                    <div class="group relative overflow-hidden aspect-[3/4] cursor-pointer">
                        <img src="{{ asset('images/third.jpeg') }}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                            <p class="text-amber-200 font-serif italic text-2xl">Novi Život</p>
                            <p class="text-gray-300 text-sm mt-2">Prvi susret, večna ljubav.</p>
                        </div>
                    </div>

                    <!-- Photo 2: Growing -->
                     <div class="group relative overflow-hidden aspect-[3/4] cursor-pointer md:mt-12">
                         <img src="{{ asset('images/laura.jpeg') }}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100">
                         <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                             <p class="text-amber-200 font-serif italic text-2xl">Mali Anđeo</p>
                             <p class="text-gray-300 text-sm mt-2">Her anın bir mucize.</p>
                         </div>
                     </div>

                    <!-- Photo 3: Now -->
                    <div class="group relative overflow-hidden aspect-[3/4] cursor-pointer">
                        <img src="{{ asset('images/laura.jpeg') }}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                            <p class="text-amber-200 font-serif italic text-2xl">Radost Naša</p>
                            <p class="text-gray-300 text-sm mt-2">Svaki tvoj osmeh je naš svet.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- NOTE FROM SRECKO -->
        <section class="bg-gray-900 py-32 px-6 flex items-center justify-center relative border-t border-white/5">
            <div class="max-w-4xl w-full text-center relative z-10">
                <svg class="w-16 h-16 text-white/10 mx-auto mb-8" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M14.017 21L14.017 18C14.017 16.0547 15.352 14.3643 17.241 13.9113C17.653 13.8203 18.067 13.784 18.472 13.784C18.986 13.784 19.489 13.832 19.972 13.9189V10.2305C19.497 10.1583 19.006 10.125 18.5 10.125C15.283 10.125 12.569 11.9792 11.391 14.6719C11.118 13.6219 10.531 12.673 9.711 11.9678C8.846 11.2363 7.747 10.8252 6.577 10.8252C5.407 10.8252 4.308 11.2363 3.443 11.9678C2.623 12.673 2.036 13.6219 1.763 14.6719C1.196 17.0729 2.164 19.294 4.372 19.8008L4.372 21H14.017ZM19 5.25C19 4.83579 18.6642 4.5 18.25 4.5H16.75C16.3358 4.5 16 4.83579 16 5.25V9H19V5.25Z" />
                </svg>
                
                <blockquote class="text-3xl md:text-5xl text-white font-serif italic leading-tight mb-12">
                    "Hvala ti što si moj dom, moj mir i moja najveća ljubav. Zajedno sa Laurom, vi ste moj čitav svet."
                </blockquote>
                
                <div class="inline-block border-t border-amber-300 w-16 mb-6"></div>
                <cite class="block text-xl text-amber-200 uppercase tracking-widest not-italic font-light">
                    Srećko
                </cite>
            </div>
        </section>

        <!-- FOOTER -->
        <footer class="bg-black py-12 border-t border-white/10">
            <div class="max-w-7xl mx-auto px-6 flex flex-col items-center gap-8">
                <p class="text-xs text-gray-500 uppercase tracking-[0.2em] hover:text-white transition-colors">
                    Created with love by Eternal Gifts
                </p>
                
                <!-- QR Placeholder -->
                <div class="p-2 bg-white rounded-sm opacity-50 hover:opacity-100 transition-opacity duration-500">
                    <img src="{{ asset('images/qr_code_classy.png') }}" alt="Scan Memory" class="w-16 h-16">
                </div>
            </div>
        </footer>
    </div>
    
    <script>
        const input = document.getElementById('password-input');
        const overlay = document.getElementById('password-overlay');
        const hint = document.getElementById('hint');
        const music = document.getElementById('bg-music');
        const video = document.getElementById('hero-video');

        // Focus input
        window.onload = () => input.focus();

        // Show hint
        setTimeout(() => {
            hint.classList.remove('opacity-0');
            hint.classList.add('opacity-40');
        }, 3000);

        function unlock() {
            input.blur();
            overlay.classList.add('hidden-overlay');
            
            // Try to play media
            music.play().catch(e => console.log("Audio play failed:", e));
            video.play().catch(e => console.log("Video play failed:", e));
        }

        input.addEventListener('input', (e) => {
            if (e.target.value.toLowerCase().trim() === 'laura') {
                unlock();
            }
        });

        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                if (e.target.value.toLowerCase().trim() !== 'laura') {
                    input.classList.add('animate-shake');
                    setTimeout(() => input.classList.remove('animate-shake'), 500);
                    input.value = '';
                } else {
                    unlock();
                }
            }
        });
    </script>
</body>
</html>
